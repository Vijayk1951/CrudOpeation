package com.example.cruddemo.service;

import java.util.List;

import com.example.cruddemo.model.Employee;

public interface EmployeeService 
{
	
	List<Employee> getAllEmployees();
	
	Employee getEmployeeById(Long id) throws EmployeeNotFoundException;
	
	Employee createEmployee(Employee employee)throws EmployeeNotFoundException;
	
	Employee updateEmployee(Long id, Employee employeeDetails)throws EmployeeNotFoundException;
	
	void deleteEmployee(Long id)throws EmployeeNotFoundException;
	
	
	
}
